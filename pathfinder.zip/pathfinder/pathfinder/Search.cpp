//Pathfinder project
#include <iostream>
#include <string>

using namespace std;

//main functions starts 
int main()
{
	cout << "\n\t\t***Welcome to Pathfinder***" << endl;

	//todo: change to a random num generator
	//this holds the number of the square to be found between 1 and 64
	int targetLocation = 42;
	//******************************************************************************************************************
	//****************************************START HUMAN PLAYER*********************************************************
	//*******************************************************************************************************************
	//
	//Int Humans variables***********
	//
	//hold human's target prediction
	int HumanTargetPosition = 0;
	//Hold range values for how large our square is for human
	int HumanLowRange = 1;
	int HumanHighRange = 64;
	//variable to tell if human has found target 
	bool didhumanFindTarget = false;

	//start human prediction loop
	do
	{
		//display prompt and let human know what is going on
		cout << "You are searching for a target on a Grid with " << HumanHighRange << " squares." << endl;

		//get input
		cout << "\nWhat location do you predict the target is at? ";
		cin >> HumanTargetPosition;


		cout << "Human you choose " << HumanTargetPosition << " as your prediction.\n";
		//give human hint if target is higher or lower than their prediction
		if (HumanTargetPosition < targetLocation)
		{
			cout << "\nHint:: The target is higher than your target prediction.\n";
		}
		else if (HumanTargetPosition > targetLocation)
		{
			cout << "\nHint:: The target is lower than your target prediction.\n";
		}
		//check human target guess
		if (HumanTargetPosition == targetLocation)
		{
			cout << "\nHuman found target at " << targetLocation << endl;
			didhumanFindTarget = true;

		}
		else
		{
			cout << "\nTarget is not at location " << HumanTargetPosition << ". Please try again." << endl;
			didhumanFindTarget = false;
		}
	} while (didhumanFindTarget == false);
	//******************************END HUMAN SEARCH*********************************
	//********************************************************************************
	//****************************************START LINEAR SEARCH AI PLAYER***********
	//********************************************************************************
	//
	//Int LINEAR variables***********
	//
	//hold  target prediction
	int linearTargetPosition = 0;
	//Hold range values for how large our square is for human
	int linearLowRange = 1;
	int linearHighRange = 64;
	//variable to tell if human has found target 
	bool didlinearFindTarget = false;
	do
	{
		//start linear prediction code loop
	//display prompt
	//
		cout << "\nLinear search is about to make a prediction\n";
		//get input from linear search AI
		linearTargetPosition++;
		if (linearTargetPosition == targetLocation)
		{
			cout << "\nLinear found target at " << targetLocation << endl;
			didhumanFindTarget = true;

		}
		else
		{
			cout << "\nTarget is not at location " << linearTargetPosition << ". Please try again." << endl;
			didlinearFindTarget = false;
		}
	} while (didlinearFindTarget == false);
	
	//exit function
	return 0;
}